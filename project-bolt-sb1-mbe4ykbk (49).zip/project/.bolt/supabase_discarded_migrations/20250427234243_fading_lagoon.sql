/*
  # Admin Access Control

  1. Changes
    - Add admin_users table
    - Add RLS policies for admin-only operations
    - Add functions to check admin status

  2. Security
    - Strict RLS policies
    - Admin role validation
    - Secure admin checks
*/

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Create function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admin_users WHERE id = user_id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add RLS policies for admin_users
CREATE POLICY "Only admins can view admin_users"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

-- Add policies for Products table
CREATE POLICY "Only admins can modify products"
  ON "Products"
  FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()));

-- Add policies for Categories table
CREATE POLICY "Only admins can modify categories"
  ON "Categories"
  FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()));

-- Add policies for Supplier table
CREATE POLICY "Only admins can modify suppliers"
  ON "Supplier"
  FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()));

-- Add policies for Countries table
CREATE POLICY "Only admins can modify countries"
  ON "Countries"
  FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()));

-- Add policies for Sources table
CREATE POLICY "Only admins can modify sources"
  ON "Sources"
  FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()));

-- Function to add an admin user
CREATE OR REPLACE FUNCTION add_admin_user(user_id uuid)
RETURNS void AS $$
BEGIN
  INSERT INTO admin_users (id)
  VALUES (user_id)
  ON CONFLICT (id) DO NOTHING;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;