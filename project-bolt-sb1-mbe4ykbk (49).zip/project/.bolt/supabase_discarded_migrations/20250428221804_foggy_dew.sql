-- Ensure specific admin user exists
INSERT INTO admin_users (id)
VALUES ('b883e6c2-15a1-45cc-b4e4-a482b0f98095')
ON CONFLICT (id) DO NOTHING;

-- Update admin check function to be more efficient
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = user_id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;