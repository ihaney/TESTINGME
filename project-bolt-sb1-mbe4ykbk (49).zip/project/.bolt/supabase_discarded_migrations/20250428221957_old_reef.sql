/*
  # Fix Products Table Access

  1. Changes
    - Ensure Products table has proper RLS policies
    - Allow public read access
    - Fix admin access policies
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access for all users" ON "Products";
DROP POLICY IF EXISTS "Allow public read access to products" ON "Products";
DROP POLICY IF EXISTS "Admin modifications for products" ON "Products";

-- Enable RLS
ALTER TABLE "Products" ENABLE ROW LEVEL SECURITY;

-- Create public read access policy
CREATE POLICY "Allow public read access to products"
  ON "Products"
  FOR SELECT
  TO public
  USING (true);

-- Create admin modification policy
CREATE POLICY "Admin modifications for products"
  ON "Products"
  FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()))
  WITH CHECK (is_admin(auth.uid()));

-- Ensure service role can bypass RLS
ALTER TABLE "Products" FORCE ROW LEVEL SECURITY;