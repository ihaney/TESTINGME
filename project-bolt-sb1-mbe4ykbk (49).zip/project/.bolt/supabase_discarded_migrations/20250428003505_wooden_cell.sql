/*
  # Simplify Admin Access Control

  1. Changes
    - Add RLS policies for admin operations
    - Allow public read access
    - Restrict modifications to service role
*/

-- Enable RLS on all tables if not already enabled
ALTER TABLE "Products" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Categories" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Countries" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Sources" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Supplier" ENABLE ROW LEVEL SECURITY;

-- Allow public read access to all tables
CREATE POLICY "Allow public read access to products"
  ON "Products"
  FOR SELECT
  TO PUBLIC
  USING (true);

CREATE POLICY "Allow public read access to categories"
  ON "Categories"
  FOR SELECT
  TO PUBLIC
  USING (true);

CREATE POLICY "Allow public read access to countries"
  ON "Countries"
  FOR SELECT
  TO PUBLIC
  USING (true);

CREATE POLICY "Allow public read access to sources"
  ON "Sources"
  FOR SELECT
  TO PUBLIC
  USING (true);

CREATE POLICY "Allow public read access to suppliers"
  ON "Supplier"
  FOR SELECT
  TO PUBLIC
  USING (true);

-- Only allow service role to modify data
ALTER TABLE "Products" FORCE ROW LEVEL SECURITY;
ALTER TABLE "Categories" FORCE ROW LEVEL SECURITY;
ALTER TABLE "Countries" FORCE ROW LEVEL SECURITY;
ALTER TABLE "Sources" FORCE ROW LEVEL SECURITY;
ALTER TABLE "Supplier" FORCE ROW LEVEL SECURITY;

-- Add admin check function
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean AS $$
BEGIN
  RETURN (SELECT is_admin FROM admin_users WHERE id = auth.uid());
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;