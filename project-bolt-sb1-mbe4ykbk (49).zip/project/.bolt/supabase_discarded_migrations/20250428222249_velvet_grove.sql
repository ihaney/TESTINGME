/*
  # Add Test Product Data

  1. Changes
    - Add test product to verify RLS policies
    - Add required related data
*/

-- Add test category if not exists
INSERT INTO "Categories" ("Category_ID", "Category_Title")
VALUES ('TEST001', 'Test Category')
ON CONFLICT ("Category_ID") DO NOTHING;

-- Add test country if not exists
INSERT INTO "Countries" ("Country_ID", "Country_Title")
VALUES ('TEST001', 'Mexico')
ON CONFLICT ("Country_ID") DO NOTHING;

-- Add test source if not exists
INSERT INTO "Sources" ("Source_ID", "Source_Title")
VALUES ('TEST001', 'Test Source')
ON CONFLICT ("Source_ID") DO NOTHING;

-- Add test supplier if not exists
INSERT INTO "Supplier" ("Supplier_ID", "Supplier_Title", "Supplier_Country_ID")
VALUES ('TEST001', 'Test Supplier', 'TEST001')
ON CONFLICT ("Supplier_ID") DO NOTHING;

-- Add test product
INSERT INTO "Products" (
  "Product_ID",
  "Product_Title",
  "Product_Price",
  "Product_Image_URL",
  "Product_Category_ID",
  "Product_Country_ID",
  "Product_Source_ID",
  "Product_Supplier_ID",
  "Product_MOQ"
)
VALUES (
  'TEST001',
  'Test Product',
  '$99.99',
  'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80',
  'TEST001',
  'TEST001',
  'TEST001',
  'TEST001',
  '10'
)
ON CONFLICT ("Product_ID") DO NOTHING;