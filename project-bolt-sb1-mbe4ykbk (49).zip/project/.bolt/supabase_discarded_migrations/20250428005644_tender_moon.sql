/*
  # Grant Admin Access

  1. Changes
    - Add initial admin user
    - Ensure proper RLS policies
*/

-- Insert admin user
INSERT INTO admin_users (id)
SELECT auth.uid()
WHERE NOT EXISTS (
  SELECT 1 FROM admin_users WHERE id = auth.uid()
);

-- Ensure RLS is enabled
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Allow admins to view admin_users
DROP POLICY IF EXISTS "Allow admins to view admin_users" ON admin_users;
CREATE POLICY "Allow admins to view admin_users"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (id = auth.uid() OR is_admin(auth.uid()));

-- Function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admin_users WHERE id = user_id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;