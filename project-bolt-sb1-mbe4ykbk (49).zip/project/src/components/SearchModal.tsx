import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { X } from 'lucide-react';
import { productsIndex } from '../lib/meilisearch';
import type { Product } from '../types';
import LoadingSpinner from './LoadingSpinner';
import { logError } from '../lib/errorLogging';

function useDebouncedValue(value: string, delay: number): string {
  const [debouncedValue, setDebouncedValue] = useState(value);

  React.useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);

  return debouncedValue;
}

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SearchModal({ isOpen, onClose }: SearchModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const debouncedQuery = useDebouncedValue(searchQuery, 300);
  const [results, setResults] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  React.useEffect(() => {
    async function performSearch() {
      if (!debouncedQuery.trim()) {
        setResults([]);
        return;
      }

      setLoading(true);
      setError(null);

      try {
        const searchResults = await productsIndex.search(debouncedQuery, {
          limit: 20,
          attributesToRetrieve: [
            'id',
            'title',
            'price',
            'image',
            'url',
            'moq',
            'country',
            'category',
            'supplier',
            'source'
          ]
        });

        const formattedResults = searchResults.hits.map(hit => ({
          id: hit.id as string,
          name: hit.title as string,
          Product_Price: hit.price as string,
          image: hit.image as string || '',
          country: hit.country as string || 'Unknown',
          category: hit.category as string || 'Unknown',
          supplier: hit.supplier as string || 'Unknown',
          Product_MOQ: hit.moq as string,
          sourceUrl: hit.url as string || '',
          marketplace: hit.source as string || 'Unknown'
        }));

        setResults(formattedResults);

        if (!formattedResults.length && debouncedQuery.length > 2) {
          logError(new Error('Search returned no results'), {
            type: 'search_no_results',
            query: debouncedQuery
          }, 'warning');
        }
      } catch (err) {
        console.error('Search error:', err);
        setError('Failed to perform search. Please try again.');
        logError(err instanceof Error ? err : new Error('Search failed'), {
          type: 'search_error',
          query: debouncedQuery
        });
      } finally {
        setLoading(false);
      }
    }

    performSearch();
  }, [debouncedQuery]);

  const handleResultClick = useCallback(
    (result: Product) => {
      navigate(`/product/${result.id}`);
      onClose();
      setSearchQuery('');
    },
    [navigate, onClose]
  );

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Enter' && searchQuery.trim()) {
        navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
        onClose();
        setSearchQuery('');
      }
    },
    [searchQuery, navigate, onClose]
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-start justify-center pt-16 px-4 md:pt-32">
      <div className="bg-gray-900 rounded-lg shadow-lg w-full max-w-3xl p-6 relative">
        <button
          onClick={() => {
            onClose();
            setSearchQuery('');
          }}
          className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
          aria-label="Close search"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="relative">
          <input
            type="text"
            placeholder="Search products, suppliers, categories..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            className="w-full bg-gray-800 text-white placeholder-gray-400 border border-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:border-[#F4A024] focus:ring-1 focus:ring-[#F4A024]"
            autoFocus
          />
          {loading && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2">
              <LoadingSpinner />
            </div>
          )}
        </div>

        {error && (
          <p className="text-red-400 mt-2 text-sm">{error}</p>
        )}

        <div className="mt-4 max-h-[60vh] overflow-y-auto">
          {results.length > 0 ? (
            <ul className="space-y-2">
              {results.map((result) => (
                <li
                  key={result.id}
                  onClick={() => handleResultClick(result)}
                  className="cursor-pointer rounded-lg p-3 hover:bg-gray-800 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    {result.image && (
                      <img
                        src={result.image}
                        alt={result.name}
                        className="w-12 h-12 object-cover rounded"
                      />
                    )}
                    <div>
                      <h3 className="font-medium text-white">{result.name}</h3>
                      <div className="flex gap-2 text-sm text-gray-400">
                        <span>{result.category}</span>
                        <span>•</span>
                        <span>{result.supplier}</span>
                        <span>•</span>
                        <span>{result.marketplace}</span>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : searchQuery && !loading && (
            <p className="text-center text-gray-400 py-4">
              No results found. Try different keywords or browse categories.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}