interface Window {
  gtag?: (...args: any[]) => void;
  dataLayer?: any[];
}